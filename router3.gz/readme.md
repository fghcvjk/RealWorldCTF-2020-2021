# router3

## Goal
Modify `index.html` to anything you like

## How does this challenge work

> Contact: `M4x` in discord
Email: demo@realworldctf.com

1. Submission Method

To submit a solution, please send an email with the subject `RealWorldCTF-3rd-router3` to demo@realworldctf.com
The email should at least contain the `exploit archive file`, `usage documentation` and your identification info.

The identification info should be presented exactly in the following format:

 - Name: <your team name>
 - Token: <your team token from platform>
 - Contact: <your email>

2. Verification Process

After receiving the email, the judge will verify your solution by demonstrating it in a live stream.

Here is what I will do when I receive your exploit files.

1. run your exploit(remeber to eliminate your debug info)
2. cross fingers
3. access `http://router_ip/index.html` and (hopefully) see the result
4. If the home page is modified, I will reward you with the flag via email.

I will keep trying for a total of **2 attemps** before I give up.

The running time for each attemp cannot exceed **5 minutes**.

I will not accept more than **5 emails** per team. If you really need more, you will need to explain to me in detail why you messed up with your first 5 submissions and convince me that you deserve a 6th chance.

## Some more info
1. the demo environment will be the same as the attachments offered to you, **except for the root password**, which to say it's launched by qemu with the same network configuration
2. **DO NOT** try to guess the root password unless you think you're lucky enough to hit the chance of `1/100**30`
3. I will run your exploit on an almost clean ubuntu 20.04(with only qemu installed), so if your exploit needs some dependence packages, please tell me how to install these in `usage documentation`

